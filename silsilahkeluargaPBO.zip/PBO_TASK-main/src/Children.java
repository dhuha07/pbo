public interface Children {
    void getFamilyDetails();
}

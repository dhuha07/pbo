# Tugas PBO
dhuha sampurna (22.0504.0030)
### Class Diagram
![image](https://github.com/scrkiddie/PBO_TASK/assets/170083313/60c74597-da26-462b-875d-0c7054db8ec9)
